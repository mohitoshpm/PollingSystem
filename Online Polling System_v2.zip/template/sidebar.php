<div class="sidenav">

        <a class="nav-menu" href="./">Dashboard </a>
        <a class="nav-menu" href="./profile.php">Profile</a>
        <a class="nav-menu" href="./user-edit.php">Edit Profile</a>
        <a class="nav-menu" href="./user-password-change.php">Change Password</a>
        <a class="nav-menu" href="./user-list.php">User List</a>
        <a class="nav-menu" href="./PollAddEdit.php">Poll Manager</a>
        <a class="nav-menu" href="./Vote.php">Give Vote</a>
        <a class="nav-menu" href="./Vote-Result.php">Vote Result</a>
        <!-- <a href="#clients">Clients</a>
        <a href="#contact">Contact</a>
        <button class="dropdown-btn">Dropdown 
          <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-container">
          <a href="#">Link 1</a>
          <a href="#">Link 2</a>
          <a href="#">Link 3</a>
        </div>
        <a href="#contact">Search</a>-->
      </div> 
